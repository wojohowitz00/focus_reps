import { useState } from "react";
import { Check, Plus, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";

interface Task {
  id: string;
  text: string;
  completed: boolean;
}

export function TaskList() {
  const [tasks, setTasks] = useState<Task[]>([
    { id: "1", text: "Deep work session", completed: false },
    { id: "2", text: "Review quarterly goals", completed: true },
    { id: "3", text: "Clear inbox", completed: false },
  ]);
  const [newTask, setNewTask] = useState("");

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    setTasks([...tasks, { id: Date.now().toString(), text: newTask, completed: false }]);
    setNewTask("");
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const removeTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="font-display font-medium text-lg tracking-tight">Intentions</h3>
        <span className="text-xs text-muted-foreground font-mono">
          {tasks.filter(t => t.completed).length}/{tasks.length}
        </span>
      </div>

      <form onSubmit={addTask} className="relative group">
        <Plus className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-accent transition-colors" />
        <Input 
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Add a new task..." 
          className="pl-9 bg-transparent border-transparent border-b-border rounded-none focus-visible:ring-0 focus-visible:border-accent px-0"
        />
      </form>

      <div className="space-y-1">
        {tasks.map((task) => (
          <div 
            key={task.id} 
            className="group flex items-center gap-3 p-2 rounded-md hover:bg-secondary/30 transition-colors"
          >
            <button
              onClick={() => toggleTask(task.id)}
              className={cn(
                "w-5 h-5 rounded-sm border flex items-center justify-center transition-all",
                task.completed 
                  ? "bg-accent border-accent text-accent-foreground" 
                  : "border-muted-foreground/30 hover:border-accent"
              )}
            >
              {task.completed && <Check className="w-3.5 h-3.5" />}
            </button>
            <span className={cn(
              "text-sm flex-1 transition-colors",
              task.completed ? "text-muted-foreground line-through decoration-border" : "text-foreground"
            )}>
              {task.text}
            </span>
            <button 
              onClick={() => removeTask(task.id)}
              className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
