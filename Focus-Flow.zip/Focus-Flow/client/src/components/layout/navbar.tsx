import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Timer, ListTodo, BarChart2, Settings, Sun, Moon } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const { theme, setTheme } = useTheme();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-6 h-16 flex items-center justify-between">
        <Link href="/" className="text-xl font-display font-bold tracking-tight hover:opacity-80 transition-opacity">
          FOCUS_
        </Link>
        
        <div className="flex items-center gap-6">
          <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors flex items-center gap-2">
            <Timer className="w-4 h-4" />
            <span className="hidden sm:inline">Timer</span>
          </Link>
          <Link href="/tasks" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors flex items-center gap-2">
            <ListTodo className="w-4 h-4" />
            <span className="hidden sm:inline">Tasks</span>
          </Link>
          <Link href="/stats" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors flex items-center gap-2">
            <BarChart2 className="w-4 h-4" />
            <span className="hidden sm:inline">Analytics</span>
          </Link>
          <div className="w-px h-4 bg-border mx-2" />
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="w-8 h-8 rounded-full"
          >
            <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>

          <button className="text-muted-foreground hover:text-primary transition-colors">
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </nav>
  );
}
