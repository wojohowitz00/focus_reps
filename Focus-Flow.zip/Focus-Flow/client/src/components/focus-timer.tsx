import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Play, Pause, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";

export function FocusTimer() {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<"focus" | "break">("focus");

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => time - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
    }

    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const toggleTimer = () => setIsActive(!isActive);

  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(mode === "focus" ? 25 * 60 : 5 * 60);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="flex flex-col items-center justify-center space-y-8 py-12">
      <div className="relative">
        {/* Architectural Rings */}
        <div className="absolute inset-0 rounded-full border border-border/30 scale-125 animate-pulse-slow" />
        <div className="absolute inset-0 rounded-full border border-accent/20 scale-110" />
        
        <div className="relative z-10 font-display text-8xl md:text-9xl font-light tracking-tighter tabular-nums text-primary select-none">
          {minutes.toString().padStart(2, "0")}
          <span className="text-muted-foreground/50">:</span>
          {seconds.toString().padStart(2, "0")}
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Button
          variant="outline"
          size="lg"
          className="rounded-full w-16 h-16 border-border hover:border-accent hover:bg-accent/5"
          onClick={toggleTimer}
        >
          {isActive ? (
            <Pause className="w-6 h-6" />
          ) : (
            <Play className="w-6 h-6 ml-1" />
          )}
        </Button>
        
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full w-12 h-12 text-muted-foreground hover:text-primary"
          onClick={resetTimer}
        >
          <RotateCcw className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex gap-2 p-1 bg-secondary/50 rounded-lg">
        <button
          onClick={() => { setMode("focus"); setTimeLeft(25 * 60); setIsActive(false); }}
          className={cn(
            "px-4 py-1.5 text-xs font-medium rounded-md transition-all",
            mode === "focus" 
              ? "bg-background text-foreground shadow-sm" 
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          Focus
        </button>
        <button
          onClick={() => { setMode("break"); setTimeLeft(5 * 60); setIsActive(false); }}
          className={cn(
            "px-4 py-1.5 text-xs font-medium rounded-md transition-all",
            mode === "break" 
              ? "bg-background text-foreground shadow-sm" 
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          Break
        </button>
      </div>
    </div>
  );
}
