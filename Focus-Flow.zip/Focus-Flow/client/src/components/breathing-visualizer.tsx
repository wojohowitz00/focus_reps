import { motion } from "framer-motion";

export function BreathingVisualizer() {
  return (
    <div className="relative w-64 h-64 flex items-center justify-center">
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.6, 0.3],
          rotate: [0, 90, 180],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute inset-0 border border-accent/20 rounded-full"
      />
      <motion.div
        animate={{
          scale: [1, 1.5, 1],
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 0.5,
        }}
        className="absolute inset-8 border border-accent/30 rounded-full"
      />
      <motion.div
        animate={{
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="w-32 h-32 bg-accent/5 backdrop-blur-sm rounded-full border border-accent/40 flex items-center justify-center"
      >
        <span className="text-xs font-mono text-accent tracking-widest uppercase opacity-70">Breathe</span>
      </motion.div>
    </div>
  );
}
