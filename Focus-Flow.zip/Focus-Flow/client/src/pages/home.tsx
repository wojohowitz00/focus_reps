import { Navbar } from "@/components/layout/navbar";
import { FocusTimer } from "@/components/focus-timer";
import { TaskList } from "@/components/task-list";
import { BreathingVisualizer } from "@/components/breathing-visualizer";
import { Card } from "@/components/ui/card";
import { Brain, Flame, Target } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background font-sans selection:bg-accent/20 selection:text-accent">
      <Navbar />
      
      <main className="container mx-auto px-6 pt-24 pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-[calc(100vh-8rem)]">
          
          {/* Left Column: Stats & Context */}
          <div className="hidden lg:flex flex-col gap-6 col-span-3">
            <Card className="p-6 bg-card border-border shadow-sm rounded-none">
              <h2 className="text-sm font-medium text-muted-foreground mb-4 uppercase tracking-wider font-mono">Daily Progress</h2>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/5 rounded-sm text-primary">
                    <Flame className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-2xl font-display font-bold">4.5h</div>
                    <div className="text-xs text-muted-foreground">Deep Work</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/5 rounded-sm text-primary">
                    <Target className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-2xl font-display font-bold">85%</div>
                    <div className="text-xs text-muted-foreground">Focus Score</div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-card border-border shadow-sm flex-1 rounded-none flex flex-col justify-center items-center">
               <BreathingVisualizer />
               <p className="mt-8 text-sm text-muted-foreground text-center max-w-[200px]">
                 Sync your breathing to maintain focus equilibrium.
               </p>
            </Card>
          </div>

          {/* Center Column: Focus Timer */}
          <div className="col-span-1 lg:col-span-6 flex flex-col items-center justify-center">
            <div className="w-full max-w-md">
              <FocusTimer />
            </div>
          </div>

          {/* Right Column: Tasks */}
          <div className="col-span-1 lg:col-span-3">
             <Card className="p-6 bg-card border-border shadow-sm h-full rounded-none">
               <TaskList />
             </Card>
          </div>
        </div>
      </main>

      {/* Background Texture Overlay */}
      <div 
        className="fixed inset-0 pointer-events-none opacity-[0.03] z-0 mix-blend-overlay"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
        }}
      />
    </div>
  );
}
